"""Smoke tests for the ForestWatch AI API; run with: python -m unittest."""
import os
import tempfile
import unittest

_TEST_DIR = tempfile.mkdtemp(prefix="forestwatch-test-")
os.environ["DB_PATH"] = os.path.join(_TEST_DIR, "test.db")

import app as forest_app  # noqa: E402


class ForestWatchApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = forest_app.app.test_client()

    def test_health(self):
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["ok"])

    def test_heartbeat_accepts_browser_coordinate_names(self):
        response = self.client.post("/heartbeat", json={
            "node_id": "test-node", "latitude": 12.97, "longitude": 77.59
        })
        self.assertEqual(response.status_code, 200)
        node_response = self.client.get("/nodes")
        nodes = node_response.get_json()
        node = next(n for n in nodes if n["node"] == "test-node")
        self.assertAlmostEqual(node["lat"], 12.97)
        self.assertAlmostEqual(node["lng"], 77.59)

    def test_heartbeat_rejects_invalid_coordinates(self):
        response = self.client.post("/heartbeat", json={
            "node": "bad-node", "lat": 120, "lng": 77
        })
        self.assertEqual(response.status_code, 400)

    def test_create_and_acknowledge_alert(self):
        response = self.client.post("/alert", json={
            "node": "alert-test", "threat": "CHAINSAW",
            "latitude": 12.97, "longitude": 77.59
        })
        self.assertEqual(response.status_code, 201)
        alert = response.get_json()
        self.assertEqual(alert["threat"], "CHAINSAW")
        self.assertAlmostEqual(alert["lat"], 12.97)
        ack_response = self.client.post(f"/alerts/{alert['id']}/ack")
        self.assertEqual(ack_response.status_code, 200)
        self.assertTrue(ack_response.get_json()["ack"])

    def test_audio_trigger_threshold(self):
        low = self.client.post("/audio-trigger", json={
            "label": "Chainsaw Detected", "confidence": 0.3
        })
        self.assertEqual(low.status_code, 200)
        self.assertFalse(low.get_json()["ok"])
        high = self.client.post("/audio-trigger", json={
            "label": "Chainsaw Detected", "confidence": 0.9
        })
        self.assertEqual(high.status_code, 200)
        self.assertTrue(high.get_json()["ok"])
        self.assertEqual(self.client.get("/audio-trigger/status").status_code, 200)


if __name__ == "__main__":
    unittest.main()
